<?php

defined('DBDRIVER')or define('DBDRIVER','mysql');
defined('DBHOST')or define('DBHOST','localhost');
defined('DBUSER')or define('DBUSER','root');
defined('DBPASS')or define('DBPASS','');
defined('CRYPTKEY') or define('CRYPTKEY','effendydarrenwahyusinarta');
