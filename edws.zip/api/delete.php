<?php
	unlink($_GET["name"]);

?>